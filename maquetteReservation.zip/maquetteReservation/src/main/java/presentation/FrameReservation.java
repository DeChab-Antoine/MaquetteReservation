/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package presentation;

import com.github.lgooddatepicker.optionalusertools.DateChangeListener;
import com.github.lgooddatepicker.zinternaltools.DateChangeEvent;
import dialog.DialogReservation;



@SuppressWarnings("serial")
public class FrameReservation extends javax.swing.JFrame {

    private DialogReservation dialog;

    public FrameReservation() {
    }

    public void initFrame() {
        initComponents();
        pickTableList.setVisible(false);
    }

    public void setDialog(DialogReservation dialog) {
        this.dialog = dialog;
    }

    // /!\ /!\ /!\ ATTENTION /!\ /!\ /!\
    // ce code est auto généré et ne doit PAS être modifié
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dateTimePanel = new javax.swing.JPanel();
        dateLabel = new javax.swing.JLabel();
        datePicker = new com.github.lgooddatepicker.components.DatePicker();
        datePicker.addDateChangeListener(new DateChangeListener(){
            public void dateChanged(DateChangeEvent dateEvent) {
                datePickerDateChanged(dateEvent);
            }
        });
        timeLabel = new javax.swing.JLabel();
        timeComboBox = new javax.swing.JComboBox<>();
        nbPersonsPanel = new javax.swing.JPanel();
        nbPersonsLabel = new javax.swing.JLabel();
        nbPersonsComboBox = new javax.swing.JComboBox<>();
        pickTablePanel = new javax.swing.JPanel();
        pickTableImage = new javax.swing.JLabel();
        pickTableLabel = new javax.swing.JLabel();
        pickTableScrollPane = new javax.swing.JScrollPane();
        pickTableList = new javax.swing.JList<>();
        namePagePanel = new javax.swing.JPanel();
        namePageLabel = new javax.swing.JLabel();
        validerAnnulerPanel = new javax.swing.JPanel();
        annulerButton = new javax.swing.JButton();
        validerButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        dateTimePanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        dateLabel.setText("1. Choisissez la date");
        dateLabel.setFont(new java.awt.Font("Noto Sans", 1, 15)); // NOI18N
        dateLabel.setPreferredSize(new java.awt.Dimension(200, 19));

        timeLabel.setText("2. Choisissez l'heure");
        timeLabel.setEnabled(false);
        timeLabel.setFont(new java.awt.Font("Noto Sans", 1, 15)); // NOI18N
        timeLabel.setPreferredSize(new java.awt.Dimension(200, 19));

        timeComboBox.setEditable(true);
        timeComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "11h30", "12h00", "12h30", "13h00", "13h30" }));
        timeComboBox.setSelectedIndex(-1);
        timeComboBox.setEnabled(false);
        timeComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                timeComboBoxActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout dateTimePanelLayout = new javax.swing.GroupLayout(dateTimePanel);
        dateTimePanel.setLayout(dateTimePanelLayout);
        dateTimePanelLayout.setHorizontalGroup(
            dateTimePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dateTimePanelLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(dateTimePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(dateTimePanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(datePicker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(dateTimePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(timeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(dateTimePanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(timeComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        dateTimePanelLayout.setVerticalGroup(
            dateTimePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dateTimePanelLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(dateTimePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dateLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(dateTimePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(datePicker, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timeComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(62, Short.MAX_VALUE))
        );

        datePicker.getAccessibleContext().setAccessibleName("");
        datePicker.getAccessibleContext().setAccessibleDescription("");

        nbPersonsPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        nbPersonsPanel.setEnabled(false);

        nbPersonsLabel.setText("3. Indiquez le nombre de personnes ");
        nbPersonsLabel.setEnabled(false);
        nbPersonsLabel.setFont(new java.awt.Font("Noto Sans", 1, 15)); // NOI18N
        nbPersonsLabel.setPreferredSize(new java.awt.Dimension(200, 19));

        nbPersonsComboBox.setEditable(true);
        nbPersonsComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2", "3", "4", "5", "6", "7", "8" }));
        nbPersonsComboBox.setSelectedIndex(-1);
        nbPersonsComboBox.setEnabled(false);
        nbPersonsComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nbPersonsComboBoxActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout nbPersonsPanelLayout = new javax.swing.GroupLayout(nbPersonsPanel);
        nbPersonsPanel.setLayout(nbPersonsPanelLayout);
        nbPersonsPanelLayout.setHorizontalGroup(
            nbPersonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(nbPersonsPanelLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(nbPersonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(nbPersonsPanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(nbPersonsComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(nbPersonsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        nbPersonsPanelLayout.setVerticalGroup(
            nbPersonsPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(nbPersonsPanelLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(nbPersonsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nbPersonsComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        pickTablePanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        pickTableImage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Plan_tables.jpg"))); // NOI18N
        pickTableImage.setEnabled(false);

        pickTableLabel.setText("4. Choisissez votre table");
        pickTableLabel.setEnabled(false);
        pickTableLabel.setFont(new java.awt.Font("Noto Sans", 1, 15)); // NOI18N
        pickTableLabel.setPreferredSize(new java.awt.Dimension(200, 19));

        pickTableList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Table 1", "Table 2", "Table 3", "Table 4" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        pickTableList.setEnabled(false);
        pickTableList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                pickTableListValueChanged(evt);
            }
        });
        pickTableScrollPane.setViewportView(pickTableList);

        javax.swing.GroupLayout pickTablePanelLayout = new javax.swing.GroupLayout(pickTablePanel);
        pickTablePanel.setLayout(pickTablePanelLayout);
        pickTablePanelLayout.setHorizontalGroup(
            pickTablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pickTablePanelLayout.createSequentialGroup()
                .addGroup(pickTablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pickTablePanelLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(pickTableLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 284, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pickTablePanelLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(pickTableImage, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pickTableScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        pickTablePanelLayout.setVerticalGroup(
            pickTablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pickTablePanelLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(pickTableLabel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pickTablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pickTableImage)
                    .addGroup(pickTablePanelLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(pickTableScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 226, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        namePagePanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        namePageLabel.setText("Réservez une table");
        namePageLabel.setFont(new java.awt.Font("Noto Sans", 1, 15)); // NOI18N

        javax.swing.GroupLayout namePagePanelLayout = new javax.swing.GroupLayout(namePagePanel);
        namePagePanel.setLayout(namePagePanelLayout);
        namePagePanelLayout.setHorizontalGroup(
            namePagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(namePagePanelLayout.createSequentialGroup()
                .addComponent(namePageLabel)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        namePagePanelLayout.setVerticalGroup(
            namePagePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(namePageLabel, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        annulerButton.setText("Annuler");
        annulerButton.setFont(new java.awt.Font("Noto Sans", 1, 15)); // NOI18N
        annulerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                annulerButtonActionPerformed(evt);
            }
        });

        validerButton.setText("Valider");
        validerButton.setEnabled(false);
        validerButton.setFocusPainted(false);
        validerButton.setFont(new java.awt.Font("Noto Sans", 1, 15)); // NOI18N
        validerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                validerButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout validerAnnulerPanelLayout = new javax.swing.GroupLayout(validerAnnulerPanel);
        validerAnnulerPanel.setLayout(validerAnnulerPanelLayout);
        validerAnnulerPanelLayout.setHorizontalGroup(
            validerAnnulerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, validerAnnulerPanelLayout.createSequentialGroup()
                .addComponent(validerButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addComponent(annulerButton)
                .addContainerGap())
        );
        validerAnnulerPanelLayout.setVerticalGroup(
            validerAnnulerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(validerAnnulerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(validerAnnulerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(validerButton)
                    .addComponent(annulerButton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(namePagePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nbPersonsPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(dateTimePanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(pickTablePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(validerAnnulerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(namePagePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dateTimePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(nbPersonsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pickTablePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(validerAnnulerPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void datePickerDateChanged(DateChangeEvent dateEvent) {
        dialog.handleDateSelectedEvent(dateEvent.getNewDate());
        throw new UnsupportedOperationException("Not implemented yet");
    }
    
    public void enableTime() {
        timeLabel.setEnabled(true);
        timeComboBox.setEnabled(true);
        timeComboBox.setEditable(false);
    }
    
    
    private void timeComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_timeComboBoxActionPerformed
        dialog.handleTimeSelectedEvent((String) timeComboBox.getSelectedItem());
    }//GEN-LAST:event_timeComboBoxActionPerformed
    
    public void enableNbPersons() {
        nbPersonsLabel.setEnabled(true);
        nbPersonsComboBox.setEnabled(true);
        nbPersonsComboBox.setEditable(false);
    } 
    
    private void validerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_validerButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_validerButtonActionPerformed

    private void annulerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_annulerButtonActionPerformed
        datePicker.setDate(null);
        
        System.out.println("1");
            
        timeLabel.setEnabled(false);
        timeComboBox.setEnabled(false);
        
        
        System.out.println("2");
        
        nbPersonsLabel.setEnabled(false);
        nbPersonsComboBox.setEnabled(false);
        
        System.out.println("3");
        
        pickTableImage.setEnabled(false);
        pickTableLabel.setEnabled(false);
        pickTableList.setEnabled(false);
        pickTableList.setVisible(false);
        
        System.out.println("4");
        
        validerButton.setEnabled(false);

    }//GEN-LAST:event_annulerButtonActionPerformed

    
    private void nbPersonsComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nbPersonsComboBoxActionPerformed
        dialog.handleNumOfPersonsSelectedEvent(Integer.parseInt(nbPersonsComboBox.getSelectedItem().toString()));
    }//GEN-LAST:event_nbPersonsComboBoxActionPerformed

    private void pickTableListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_pickTableListValueChanged
        if (!evt.getValueIsAdjusting()) {
            int selectedIndex = pickTableList.getSelectedIndex();
            if (selectedIndex != -1) {
                dialog.handleTableSelectedEvent(selectedIndex);
            }
        }
    }//GEN-LAST:event_pickTableListValueChanged
    
    public void enablePickTable() {
        pickTableImage.setEnabled(true);
        pickTableLabel.setEnabled(true);
        pickTableList.setEnabled(true);
        pickTableList.setVisible(true);

    }
    
        
    public void enableValider() {
        validerButton.setEnabled(true);
    }
    
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton annulerButton;
    private javax.swing.JLabel dateLabel;
    private com.github.lgooddatepicker.components.DatePicker datePicker;
    private javax.swing.JPanel dateTimePanel;
    private javax.swing.JLabel namePageLabel;
    private javax.swing.JPanel namePagePanel;
    private javax.swing.JComboBox<String> nbPersonsComboBox;
    private javax.swing.JLabel nbPersonsLabel;
    private javax.swing.JPanel nbPersonsPanel;
    private javax.swing.JLabel pickTableImage;
    private javax.swing.JLabel pickTableLabel;
    private javax.swing.JList<String> pickTableList;
    private javax.swing.JPanel pickTablePanel;
    private javax.swing.JScrollPane pickTableScrollPane;
    private javax.swing.JComboBox<String> timeComboBox;
    private javax.swing.JLabel timeLabel;
    private javax.swing.JPanel validerAnnulerPanel;
    private javax.swing.JButton validerButton;
    // End of variables declaration//GEN-END:variables

}
