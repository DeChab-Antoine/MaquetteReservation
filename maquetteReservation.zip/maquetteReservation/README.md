[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/JnU5cK8b)
# UPS - Licence Info - ILU2

### NOM : DE CHABANNES
### Prénom : Antoine
### Groupe de TP :
- [x] A11
- [ ] A12
- [ ] B11
- [ ] B12

## Instructions

- Éditer ce README.md en remplissant votre `NOM`, `Prénom`, et `Groupe de TP`  
  (remplacer `[ ]` par `[x]` (*x* minuscule) dans la bonne ligne ci-dessus).

- Clonez ce dépôt GitHub en utilisant un terminal (ou Git-Bash sous Windows) :  
  `git clone https://github.com/UPS-ILU/...`

- Suivez les instructions de la feuille de TP pour importer le projet dans votre workspace Eclipse.

⚠ N'oubliez pas de pousser le code en ligne à chaque fin de séance et **avant** la date limite du projet (présent sur moodle) ⚠
